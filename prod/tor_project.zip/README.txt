This program parses an onion forum and retrieves data along the way in order to store them in a mongoDB for further analysis.

In order to run it, you need to be running python3.5, having all of the required libraries in the requirements.txt file downloaded via pip or easy_install and provide to the commandline your tor browser folder.

Example: python python/crawler.py path_to/my_tor_browser/folder
